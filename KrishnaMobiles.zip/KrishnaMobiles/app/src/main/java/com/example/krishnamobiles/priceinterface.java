
    package com.example.krishnamobiles;


    public interface priceinterface {

        public void onTaskComplete(String result);

    }


