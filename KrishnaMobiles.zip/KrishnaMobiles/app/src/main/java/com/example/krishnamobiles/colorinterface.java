package com.example.krishnamobiles;


    public interface colorinterface {
        // Define data you like to return from AysncTask
        public void onTaskComplete(String result);

}
